/** Automatically generated file. DO NOT MODIFY */
package com.tutecentral.swipelistviewexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}