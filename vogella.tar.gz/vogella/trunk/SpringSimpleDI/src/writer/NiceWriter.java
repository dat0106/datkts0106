package writer;

public class NiceWriter implements IWriter {
	public void writer (String s){
		System.out.println("The string is " + s);
	}
}
