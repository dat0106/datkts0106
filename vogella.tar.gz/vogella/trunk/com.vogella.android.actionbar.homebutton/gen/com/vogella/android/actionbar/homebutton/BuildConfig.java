/** Automatically generated file. DO NOT MODIFY */
package com.vogella.android.actionbar.homebutton;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}