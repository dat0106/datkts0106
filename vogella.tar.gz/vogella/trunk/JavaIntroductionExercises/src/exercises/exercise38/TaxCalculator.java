package exercises.exercise38;

public class TaxCalculator {
	public float calculateTax(Person person) {
		return 0;
	}
}
