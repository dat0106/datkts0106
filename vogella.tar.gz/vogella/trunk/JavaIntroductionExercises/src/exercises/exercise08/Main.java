package exercises.exercise08;

public class Main {
	public static void main(String[] args) {
		Math math = new Math();
		System.out.println(math.multiply(5, 2));
		System.out.println(math.add(8, 2));
		System.out.println(math.substact(5, 2));
		System.out.println(math.divide(5, 2));
	}
}
