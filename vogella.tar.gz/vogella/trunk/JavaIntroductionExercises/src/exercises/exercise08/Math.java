package exercises.exercise08;

public class Math {
	public int multiply(int a, int b) {
		return a * b;
	}

	public int add(int a, int b) {
		return a + b;
	}

	public int substact(int a, int b) {
		return a + b;
	}

	public double divide(int a, int b) {
		return a / b;
	}
}
