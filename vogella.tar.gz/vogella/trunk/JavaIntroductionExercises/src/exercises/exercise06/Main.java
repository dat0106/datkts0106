package exercises.exercise06;

public class Main {
	public static void main(String[] args) {
		Person person = new Person("Jim", "Knopf");
		person.writeName();
	}
}
