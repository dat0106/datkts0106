package exercises.exercise40;

public class MinMax {
	private int min = 0;
	private int max = 0;

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

}
