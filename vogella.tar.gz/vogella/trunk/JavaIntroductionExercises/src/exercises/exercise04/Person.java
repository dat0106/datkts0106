package exercises.exercise04;

class Person { 
	String firstname = "Jim";
	String lastname = "Knopf";
	int age = 12;

	void writeName() {
		System.out.println(firstname + " " + lastname + "" + age);
	}

}
