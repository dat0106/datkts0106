package test;

public class Mathe {

	public void addWrite(int a, int b) {
		System.out.println(a + b);
	}

	public int addiereUndPlusEins(int a, int b) {
		return a + b + 1;
	}

	public int multi(int a, int b) {
		return a * b;
	}
}
