package test;

public class MyOtherClass {
	String myvalue;
	Dog dog;

	public String getMyvalue() {
		return myvalue;
	}

	public void setMyvalue(String myvalue) {
		this.myvalue = myvalue;
	}

	public Dog getDog() {
		return dog;
	}

	public void setDog(Dog dog) {
		this.dog = dog;
	}
}
