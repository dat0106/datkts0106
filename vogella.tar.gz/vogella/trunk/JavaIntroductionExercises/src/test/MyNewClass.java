package test;

public class MyNewClass {
	private String var1;

	public MyNewClass(String para1) {
		var1 = para1;
		// or this.var1= para1;
	}

	public void doSomeThing() {

	}

	public void doSomeThing2(int a, Person person) {

	}

	public int doSomeThing3(String a, String b, Person person) {
		return 5; // Any value will do for this example
	}

}
