package test;

public class Help {
	public void hello() {
		String array[] = new String[5];
	}
}
