package test;

public class Math {
	int addFactor = 0;;

	public Math(int a) {
		addFactor = a;
	}

	public double divide(double a, double b) {
		return a / b + a;
	}
}
