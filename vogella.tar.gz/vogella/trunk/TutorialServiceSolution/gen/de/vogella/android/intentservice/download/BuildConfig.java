/** Automatically generated file. DO NOT MODIFY */
package de.vogella.android.intentservice.download;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}