/** Automatically generated file. DO NOT MODIFY */
package com.vogella.android.actionbar.navigationdrawer.exercise;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}