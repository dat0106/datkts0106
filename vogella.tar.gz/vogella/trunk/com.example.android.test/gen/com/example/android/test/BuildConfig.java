/** Automatically generated file. DO NOT MODIFY */
package com.example.android.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}