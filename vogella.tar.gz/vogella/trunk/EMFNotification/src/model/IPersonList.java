/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package model;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * @model
 * @generated
 */
public interface IPersonList extends EObject {
	/**
	 * @model containment="true"
	 * @generated
	 */
	EList<IPerson> getPersons();

} // IPersonList
