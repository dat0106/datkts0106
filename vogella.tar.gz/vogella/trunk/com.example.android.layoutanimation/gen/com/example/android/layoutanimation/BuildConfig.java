/** Automatically generated file. DO NOT MODIFY */
package com.example.android.layoutanimation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}