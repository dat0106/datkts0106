/** Automatically generated file. DO NOT MODIFY */
package de.vogella.tutorial.maps2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}