/** Automatically generated file. DO NOT MODIFY */
package com.vogella.android.actionbar.spinner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}