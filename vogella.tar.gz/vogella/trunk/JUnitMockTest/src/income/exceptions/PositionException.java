package income.exceptions;

public class PositionException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public PositionException(String message) {
		super(message);
	}
}
