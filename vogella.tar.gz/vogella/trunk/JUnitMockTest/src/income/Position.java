package income;

public enum Position {
	BOSS, PROGRAMMER, SURFER
}
