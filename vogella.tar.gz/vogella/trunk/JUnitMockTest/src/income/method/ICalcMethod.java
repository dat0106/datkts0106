package income.method;

import income.Position;

public interface ICalcMethod {

	public abstract double calc(Position position);

}