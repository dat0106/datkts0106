/** Automatically generated file. DO NOT MODIFY */
package com.vogella.android.actionbar.navigationdrawer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}