/** Automatically generated file. DO NOT MODIFY */
package com.vogella.android.actionbar.progress;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}