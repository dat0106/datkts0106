/** Automatically generated file. DO NOT MODIFY */
package de.vogella.android.widget.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}