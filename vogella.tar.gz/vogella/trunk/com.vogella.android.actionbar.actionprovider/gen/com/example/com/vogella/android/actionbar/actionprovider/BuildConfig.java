/** Automatically generated file. DO NOT MODIFY */
package com.example.com.vogella.android.actionbar.actionprovider;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}