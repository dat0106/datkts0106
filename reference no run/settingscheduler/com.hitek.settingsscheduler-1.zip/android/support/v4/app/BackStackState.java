

android.os.Parcel
android.os.Parcelable
android.os.Parcelable.Creator
android.text.TextUtils
android.util.Log
java.util.ArrayList

BackStackState
  

  CREATOR = ()
  
    createFromParcel
    
      
    
    
    []newArray
    
      
    
  
  mBreadCrumbShortTitleRes
  mBreadCrumbShortTitleText
  mBreadCrumbTitleRes
  mBreadCrumbTitleText
  mIndex
  mName
  []mOps
  mTransition
  mTransitionStyle
  
  BackStackState
  
    mOps = paramParcel.createIntArray();
    this.mTransition = paramParcel.readInt();
    this.mTransitionStyle = paramParcel.readInt();
    this.mName = paramParcel.readString();
    this.mIndex = paramParcel.readInt();
    this.mBreadCrumbTitleRes = paramParcel.readInt();
    this.mBreadCrumbTitleText = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.mBreadCrumbShortTitleRes = paramParcel.readInt();
    this.mBreadCrumbShortTitleText = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
  }
  
  public BackStackState(FragmentManagerImpl paramFragmentManagerImpl, BackStackRecord paramBackStackRecord)
  {
    int i = 0;
    int m;
    BackStackRecord.Op localOp2;
    for (Object localObject = paramBackStackRecord.mHead;; localOp2 = m.next)
    {
      BackStackRecord.Op localOp1;
      if (localObject == null)
      {
        this.mOps = new int[i + 7 * paramBackStackRecord.mNumOp];
        if (paramBackStackRecord.mAddToBackStack)
        {
          localOp1 = paramBackStackRecord.mHead;
          int i2 = 0;
          if (localOp1 == null)
          {
            this.mTransition = paramBackStackRecord.mTransition;
            this.mTransitionStyle = paramBackStackRecord.mTransitionStyle;
            this.mName = paramBackStackRecord.mName;
            this.mIndex = paramBackStackRecord.mIndex;
            this.mBreadCrumbTitleRes = paramBackStackRecord.mBreadCrumbTitleRes;
            this.mBreadCrumbTitleText = paramBackStackRecord.mBreadCrumbTitleText;
            this.mBreadCrumbShortTitleRes = paramBackStackRecord.mBreadCrumbShortTitleRes;
            this.mBreadCrumbShortTitleText = paramBackStackRecord.mBreadCrumbShortTitleText;
            return;
          }
          localObject = this.mOps;
          int n = i2 + 1;
          localObject[i2] = localOp1.cmd;
          int[] arrayOfInt4 = this.mOps;
          int k = n + 1;
          if (localOp1.fragment == null) {
            i2 = -1;
          } else {
            i2 = localOp1.fragment.mIndex;
          }
          arrayOfInt4[n] = i2;
          int[] arrayOfInt2 = this.mOps;
          i2 = k + 1;
          arrayOfInt2[k] = localOp1.enterAnim;
          int[] arrayOfInt1 = this.mOps;
          int i1 = i2 + 1;
          arrayOfInt1[i2] = localOp1.exitAnim;
          int[] arrayOfInt3 = this.mOps;
          m = i1 + 1;
          arrayOfInt3[i1] = localOp1.popEnterAnim;
          arrayOfInt3 = this.mOps;
          i1 = m + 1;
          arrayOfInt3[m] = localOp1.popExitAnim;
          int i3;
          if (localOp1.removed == null)
          {
            arrayOfInt3 = this.mOps;
            m = i1 + 1;
            arrayOfInt3[i1] = 0;
          }
          else
          {
            m = localOp1.removed.size();
            arrayOfInt4 = this.mOps;
            i3 = i1 + 1;
            arrayOfInt4[i1] = m;
            i1 = 0;
          }
          for (int i4 = i3;; i4 = i3)
          {
            if (i1 >= m)
            {
              m = i4;
              localOp1 = localOp1.next;
              i3 = m;
              break;
            }
            arrayOfInt4 = this.mOps;
            i3 = i4 + 1;
            arrayOfInt4[i4] = ((Fragment)localOp1.removed.get(i1)).mIndex;
            i1++;
          }
        }
        throw new IllegalStateException("Not on back stack");
      }
      if (m.removed != null)
      {
        int j;
        localOp1 += m.removed.size();
      }
    }
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public BackStackRecord instantiate(FragmentManagerImpl paramFragmentManagerImpl)
  {
    BackStackRecord localBackStackRecord = new BackStackRecord(paramFragmentManagerImpl);
    int j = 0;
    int i = 0;
    if (j >= this.mOps.length)
    {
      localBackStackRecord.mTransition = this.mTransition;
      localBackStackRecord.mTransitionStyle = this.mTransitionStyle;
      localBackStackRecord.mName = this.mName;
      localBackStackRecord.mIndex = this.mIndex;
      localBackStackRecord.mAddToBackStack = true;
      localBackStackRecord.mBreadCrumbTitleRes = this.mBreadCrumbTitleRes;
      localBackStackRecord.mBreadCrumbTitleText = this.mBreadCrumbTitleText;
      localBackStackRecord.mBreadCrumbShortTitleRes = this.mBreadCrumbShortTitleRes;
      localBackStackRecord.mBreadCrumbShortTitleText = this.mBreadCrumbShortTitleText;
      localBackStackRecord.bumpBackStackNesting(1);
      return localBackStackRecord;
    }
    BackStackRecord.Op localOp = new BackStackRecord.Op();
    int[] arrayOfInt3 = this.mOps;
    int m = j + 1;
    localOp.cmd = arrayOfInt3[j];
    if (FragmentManagerImpl.DEBUG) {
      Log.v("FragmentManager", "Instantiate " + localBackStackRecord + " op #" + i + " base fragment #" + this.mOps[m]);
    }
    arrayOfInt3 = this.mOps;
    j = m + 1;
    m = arrayOfInt3[m];
    if (m < 0) {
      localOp.fragment = null;
    } else {
      localOp.fragment = ((Fragment)paramFragmentManagerImpl.mActive.get(m));
    }
    int[] arrayOfInt2 = this.mOps;
    int i1 = j + 1;
    localOp.enterAnim = arrayOfInt2[j];
    int[] arrayOfInt1 = this.mOps;
    int n = i1 + 1;
    localOp.exitAnim = arrayOfInt1[i1];
    int[] arrayOfInt4 = this.mOps;
    int k = n + 1;
    localOp.popEnterAnim = arrayOfInt4[n];
    arrayOfInt4 = this.mOps;
    n = k + 1;
    localOp.popExitAnim = arrayOfInt4[k];
    arrayOfInt4 = this.mOps;
    k = n + 1;
    n = arrayOfInt4[n];
    int i2;
    if (n > 0)
    {
      localOp.removed = new ArrayList(n);
      i2 = 0;
    }
    for (;;)
    {
      if (i2 >= n)
      {
        k = k;
        localBackStackRecord.addOp(localOp);
        i++;
        break;
      }
      if (FragmentManagerImpl.DEBUG) {
        Log.v("FragmentManager", "Instantiate " + localBackStackRecord + " set remove fragment #" + this.mOps[k]);
      }
      ArrayList localArrayList = paramFragmentManagerImpl.mActive;
      int[] arrayOfInt5 = this.mOps;
      Fragment localFragment2 = k + 1;
      Fragment localFragment1 = (Fragment)localArrayList.get(arrayOfInt5[k]);
      localOp.removed.add(localFragment1);
      i2++;
      localFragment1 = localFragment2;
    }
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeIntArray(this.mOps);
    paramParcel.writeInt(this.mTransition);
    paramParcel.writeInt(this.mTransitionStyle);
    paramParcel.writeString(this.mName);
    paramParcel.writeInt(this.mIndex);
    paramParcel.writeInt(this.mBreadCrumbTitleRes);
    TextUtils.writeToParcel(this.mBreadCrumbTitleText, paramParcel, 0);
    paramParcel.writeInt(this.mBreadCrumbShortTitleRes);
    TextUtils.writeToParcel(this.mBreadCrumbShortTitleText, paramParcel, 0);
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.BackStackState
 * JD-Core Version:    0.7.0.1
 */