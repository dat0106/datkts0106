package android.support.v4.widget;

import android.widget.Scroller;

class ScrollerCompatIcs
{
  public static float getCurrVelocity(Scroller paramScroller)
  {
    return paramScroller.getCurrVelocity();
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.ScrollerCompatIcs
 * JD-Core Version:    0.7.0.1
 */