package com.google.ads.util;

public abstract interface f<T>
{
  public abstract T b();
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.ads.util.f
 * JD-Core Version:    0.7.0.1
 */