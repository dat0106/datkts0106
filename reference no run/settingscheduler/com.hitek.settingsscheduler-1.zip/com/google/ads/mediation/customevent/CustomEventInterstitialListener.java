package com.google.ads.mediation.customevent;

public abstract interface CustomEventInterstitialListener
  extends CustomEventListener
{
  public abstract void onReceivedAd();
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.ads.mediation.customevent.CustomEventInterstitialListener
 * JD-Core Version:    0.7.0.1
 */