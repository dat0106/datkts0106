package com.google.ads;

import android.net.Uri;

public class af
{
  public static final Uri a = Uri.parse("content://com.google.plus.platform/ads");
  public static final Uri b = Uri.parse("content://com.google.plus.platform/token");
  public static final String[] c;
  public static final String[] d;
  
  static
  {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = "_id";
    arrayOfString[1] = "has_plus1";
    c = arrayOfString;
    arrayOfString = new String[1];
    arrayOfString[0] = "drt";
    d = arrayOfString;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.ads.af
 * JD-Core Version:    0.7.0.1
 */