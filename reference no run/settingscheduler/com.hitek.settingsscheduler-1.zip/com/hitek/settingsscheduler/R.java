package com.hitek.settingsscheduler;

public final class R
{
  public static final class array
  {
    public static final int task_menu_options = 2131165184;
  }
  
  public static final class attr {}
  
  public static final class color
  {
    public static final int daySelected_background = 2130968577;
    public static final int toolbar_background = 2130968576;
    public static final int transparent_background = 2130968578;
  }
  
  public static final class drawable
  {
    public static final int add = 2130837504;
    public static final int airplane_off = 2130837505;
    public static final int airplane_on = 2130837506;
    public static final int bluetooth = 2130837507;
    public static final int border = 2130837508;
    public static final int btn_check_off = 2130837509;
    public static final int btn_check_on = 2130837510;
    public static final int clock = 2130837511;
    public static final int dropdown = 2130837512;
    public static final int launcher = 2130837513;
    public static final int lock = 2130837514;
    public static final int mobile_data = 2130837515;
    public static final int run = 2130837516;
    public static final int screen = 2130837517;
    public static final int sound_off = 2130837518;
    public static final int sound_on = 2130837519;
    public static final int vibrate_on = 2130837520;
    public static final int wifi = 2130837521;
  }
  
  public static final class id
  {
    public static final int addTaskImageView = 2131296258;
    public static final int buttonTaskType = 2131296264;
    public static final int cancelButton = 2131296262;
    public static final int dayOfWeekView = 2131296290;
    public static final int daysInfoTextView = 2131296267;
    public static final int enabledCheckBoxImage = 2131296286;
    public static final int fridayCheckBox = 2131296273;
    public static final int listViewTasks = 2131296259;
    public static final int mainActivityToolbarView = 2131296257;
    public static final int menu_settings = 2131296291;
    public static final int mondayCheckBox = 2131296269;
    public static final int relativeViewMainActivity = 2131296256;
    public static final int relativeViewTaskSettings = 2131296260;
    public static final int saturdayCheckBox = 2131296274;
    public static final int saveButton = 2131296263;
    public static final int saveCancelView = 2131296261;
    public static final int sundayCheckBox = 2131296268;
    public static final int taskTypeAndValueView = 2131296288;
    public static final int taskTypeImageView = 2131296287;
    public static final int taskValueButton = 2131296265;
    public static final int tasksRowLayout = 2131296285;
    public static final int thursdayCheckBox = 2131296272;
    public static final int timeOfDayView = 2131296289;
    public static final int timePicker = 2131296266;
    public static final int tuesdayCheckBox = 2131296270;
    public static final int wednesdayCheckBox = 2131296271;
    public static final int week1CheckBox = 2131296276;
    public static final int week2CheckBox = 2131296277;
    public static final int week3CheckBox = 2131296278;
    public static final int week4CheckBox = 2131296279;
    public static final int week5CheckBox = 2131296280;
    public static final int week6CheckBox = 2131296281;
    public static final int weeksEvenCheckBox = 2131296284;
    public static final int weeksMonthlyTextView = 2131296275;
    public static final int weeksOddCheckBox = 2131296283;
    public static final int weeksYearlyTextView = 2131296282;
  }
  
  public static final class layout
  {
    public static final int activity_main = 2130903040;
    public static final int activity_task_settings = 2130903041;
    public static final int activity_zombie_brightness = 2130903042;
    public static final int tasks_row_layout = 2130903043;
  }
  
  public static final class menu
  {
    public static final int activity_main = 2131230720;
    public static final int activity_task_settings = 2131230721;
    public static final int activity_zombie_brightness = 2131230722;
  }
  
  public static final class string
  {
    public static final int alarm_volume_title = 2131034126;
    public static final int all_volume_title = 2131034123;
    public static final int app_name = 2131034112;
    public static final int bluetooth = 2131034120;
    public static final int brightness = 2131034131;
    public static final int cancel = 2131034114;
    public static final int data_usage_enable_mobile = 2131034130;
    public static final int delete = 2131034116;
    public static final int gadget_brightness_state_auto = 2131034132;
    public static final int gadget_state_off = 2131034118;
    public static final int gadget_state_on = 2131034117;
    public static final int media_volume_title = 2131034125;
    public static final int menu_save = 2131034115;
    public static final int monthly = 2131034134;
    public static final int notification_volume_title = 2131034127;
    public static final int repeats_label = 2131034136;
    public static final int ring_volume_title = 2131034124;
    public static final int screen_timeout = 2131034129;
    public static final int settings_label = 2131034113;
    public static final int sound_category_system_title = 2131034128;
    public static final int sound_settings = 2131034121;
    public static final int vibrate_in_silent_title = 2131034122;
    public static final int week_view = 2131034133;
    public static final int wifi_settings_title = 2131034119;
    public static final int yearly_plain = 2131034135;
  }
  
  public static final class style
  {
    public static final int AppBaseTheme = 2131099648;
    public static final int AppTheme = 2131099649;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.hitek.settingsscheduler.R
 * JD-Core Version:    0.7.0.1
 */