

android.accessibilityservice.AccessibilityServiceInfo
android.content.pm.ResolveInfo
android.os.Build.VERSION

AccessibilityServiceInfoCompat

  FEEDBACK_ALL_MASK = -1
  IMPL
  
  static
  
     (SDK_INT<14 {
      IMPL = ()
     {
      IMPL = ()
    
  
  
  feedbackTypeToString
  
     = ()
    append"["
     (;;)
    
       (<=0
      
        append"]"
        toString()
      
       = 1numberOfTrailingZeros
      0xFFFFFFFF
       (length()>1 {
        append", "
      
       (
      
      : 
        
      1: 
        append"FEEDBACK_SPOKEN"
        
      2: 
        append"FEEDBACK_HAPTIC"
        
      4: 
        append"FEEDBACK_AUDIBLE"
        
      8: 
        append"FEEDBACK_VISUAL"
        
      16: 
        append"FEEDBACK_GENERIC"
      
    
  
  
  flagToString
  
    
     (
    
    : 
       = 
      
    1: 
       = "DEFAULT"
    
    
  
  
  getCanRetrieveWindowContent
  
    IMPLgetCanRetrieveWindowContent
  
  
  getDescription
  
    IMPLgetDescription
  
  
  getId
  
    IMPLgetId
  
  
  getResolveInfo
  
    IMPLgetResolveInfo
  
  
  getSettingsActivityName
  
    IMPLgetSettingsActivityName
  
  
  AccessibilityServiceInfoIcsImpl
    
  
    getCanRetrieveWindowContent
    
      getCanRetrieveWindowContent
    
    
    getDescription
    
      getDescription
    
    
    getId
    
      getId
    
    
    getResolveInfo
    
      getResolveInfo
    
    
    getSettingsActivityName
    
      getSettingsActivityName
    
  
  
  AccessibilityServiceInfoStubImpl
    
  
    getCanRetrieveWindowContent
    
      
    
    
    getDescription
    
      
    
    
    getId
    
      
    
    
    getResolveInfo
    
      
    
    
    getSettingsActivityName
    
      
    
  
  
  AccessibilityServiceInfoVersionImpl
  
    getCanRetrieveWindowContent
    
    getDescription
    
    getId
    
    getResolveInfo
    
    getSettingsActivityName
  



/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat
 * JD-Core Version:    0.7.0.1
 */