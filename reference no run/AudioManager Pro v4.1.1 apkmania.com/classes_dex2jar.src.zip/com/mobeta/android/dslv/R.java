package com.mobeta.android.dslv;

public final class R
{
  public static final class dimen
  {
    public static final int drag_list_item_height = 2131165184;
  }
  
  public static final class attr
  {
    public static final int collapsed_height = 2130771980;
    public static final int drag_scroll_start = 2130771981;
    public static final int float_background_color = 2130771983;
    public static final int max_drag_scroll_speed = 2130771982;
    public static final int remove_mode = 2130771984;
    public static final int track_drag_scroll = 2130771985;
  }
  
  public static final class drawable
  {
    public static final int drag = 2130837696;
  }
  
  public static final class styleable
  {
    public static final int[] DragSortListView;
    public static final int DragSortListView_collapsed_height = 0;
    public static final int DragSortListView_drag_scroll_start = 1;
    public static final int DragSortListView_float_background_color = 3;
    public static final int DragSortListView_max_drag_scroll_speed = 2;
    public static final int DragSortListView_remove_mode = 4;
    public static final int DragSortListView_track_drag_scroll = 5;
    
    static
    {
      int[] arrayOfInt = new int[6];
      arrayOfInt[0] = 2130771980;
      arrayOfInt[1] = 2130771981;
      arrayOfInt[2] = 2130771982;
      arrayOfInt[3] = 2130771983;
      arrayOfInt[4] = 2130771984;
      arrayOfInt[5] = 2130771985;
      DragSortListView = arrayOfInt;
    }
  }
  
  public static final class layout
  {
    public static final int drag_list_item = 2130903065;
  }
  
  public static final class string
  {
    public static final int app_name = 2131296256;
  }
  
  public static final class id
  {
    public static final int drag = 2131230725;
    public static final int fling = 2131230721;
    public static final int none = 2131230720;
    public static final int slide = 2131230722;
    public static final int slideLeft = 2131230724;
    public static final int slideRight = 2131230723;
    public static final int text = 2131230779;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.mobeta.android.dslv.R
 * JD-Core Version:    0.7.0.1
 */