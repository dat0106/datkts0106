package com.astuetz.viewpager.extensions;

import android.view.View;

public abstract interface TabsAdapter
{
  public abstract View getView(int paramInt);
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.astuetz.viewpager.extensions.TabsAdapter
 * JD-Core Version:    0.7.0.1
 */