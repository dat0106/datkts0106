package com.astuetz.viewpager.extensions;

public abstract interface SwipeyTab
{
  public abstract void setHighlightPercentage(int paramInt);
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.astuetz.viewpager.extensions.SwipeyTab
 * JD-Core Version:    0.7.0.1
 */