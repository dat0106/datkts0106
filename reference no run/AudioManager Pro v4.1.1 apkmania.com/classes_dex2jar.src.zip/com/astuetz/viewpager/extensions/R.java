package com.astuetz.viewpager.extensions;

public final class R
{
  public static final class attr
  {
    public static final int dividerColor = 2130771975;
    public static final int dividerDrawable = 2130771978;
    public static final int dividerMarginBottom = 2130771977;
    public static final int dividerMarginTop = 2130771976;
    public static final int fadeOutDelay = 2130771968;
    public static final int fadeOutDuration = 2130771969;
    public static final int lineColor = 2130771971;
    public static final int lineColorSelected = 2130771972;
    public static final int lineHeight = 2130771973;
    public static final int lineHeightSelected = 2130771974;
    public static final int outsideOffset = 2130771979;
    public static final int textColorSelected = 2130771970;
  }
  
  public static final class styleable
  {
    public static final int[] ViewPagerExtensions;
    public static final int ViewPagerExtensions_dividerColor = 7;
    public static final int ViewPagerExtensions_dividerDrawable = 10;
    public static final int ViewPagerExtensions_dividerMarginBottom = 9;
    public static final int ViewPagerExtensions_dividerMarginTop = 8;
    public static final int ViewPagerExtensions_fadeOutDelay = 0;
    public static final int ViewPagerExtensions_fadeOutDuration = 1;
    public static final int ViewPagerExtensions_lineColor = 3;
    public static final int ViewPagerExtensions_lineColorSelected = 4;
    public static final int ViewPagerExtensions_lineHeight = 5;
    public static final int ViewPagerExtensions_lineHeightSelected = 6;
    public static final int ViewPagerExtensions_outsideOffset = 11;
    public static final int ViewPagerExtensions_textColorSelected = 2;
    
    static
    {
      int[] arrayOfInt = new int[12];
      arrayOfInt[0] = 2130771968;
      arrayOfInt[1] = 2130771969;
      arrayOfInt[2] = 2130771970;
      arrayOfInt[3] = 2130771971;
      arrayOfInt[4] = 2130771972;
      arrayOfInt[5] = 2130771973;
      arrayOfInt[6] = 2130771974;
      arrayOfInt[7] = 2130771975;
      arrayOfInt[8] = 2130771976;
      arrayOfInt[9] = 2130771977;
      arrayOfInt[10] = 2130771978;
      arrayOfInt[11] = 2130771979;
      ViewPagerExtensions = arrayOfInt;
    }
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.astuetz.viewpager.extensions.R
 * JD-Core Version:    0.7.0.1
 */