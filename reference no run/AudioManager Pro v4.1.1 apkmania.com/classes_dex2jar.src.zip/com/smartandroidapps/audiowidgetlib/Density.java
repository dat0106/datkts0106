package com.smartandroidapps.audiowidgetlib;

import android.util.DisplayMetrics;

public class Density
{
  public static int getDensityDpi(DisplayMetrics paramDisplayMetrics)
  {
    return paramDisplayMetrics.densityDpi;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.smartandroidapps.audiowidgetlib.Density
 * JD-Core Version:    0.7.0.1
 */