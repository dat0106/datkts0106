package com.smartandroidapps.audiowidgetlib.util;

import android.app.backup.BackupManager;
import android.content.Context;

class OldAPIHelper8
{
  static void dataChanged(Context paramContext)
  {
    new BackupManager(paramContext).dataChanged();
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.smartandroidapps.audiowidgetlib.util.OldAPIHelper8
 * JD-Core Version:    0.7.0.1
 */