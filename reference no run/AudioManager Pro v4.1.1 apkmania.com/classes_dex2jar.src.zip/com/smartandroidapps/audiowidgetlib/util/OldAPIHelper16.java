package com.smartandroidapps.audiowidgetlib.util;

import android.app.Notification;

class OldAPIHelper16
{
  public static void setNotificationLowPriority(Notification paramNotification)
  {
    paramNotification.priority = -1;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.smartandroidapps.audiowidgetlib.util.OldAPIHelper16
 * JD-Core Version:    0.7.0.1
 */