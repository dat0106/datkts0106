package com.smartandroidapps.audiowidgetlib.data;

import android.content.res.Resources;

public class Respair
{
  public Resources res;
  public int resID;
  public String widgetskin;
  
  public Respair(Resources paramResources, int paramInt, String paramString)
  {
    this.res = paramResources;
    this.resID = paramInt;
    this.widgetskin = paramString;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.smartandroidapps.audiowidgetlib.data.Respair
 * JD-Core Version:    0.7.0.1
 */