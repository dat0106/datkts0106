package com.smartandroidapps.audiowidgetpro;

public final class Manifest
{
  public static final class permission
  {
    public static final String AUDIOMANAGER_API = "com.smartandroidapps.audiowidgetpro.permission.AUDIOMANAGER_API";
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.smartandroidapps.audiowidgetpro.Manifest
 * JD-Core Version:    0.7.0.1
 */