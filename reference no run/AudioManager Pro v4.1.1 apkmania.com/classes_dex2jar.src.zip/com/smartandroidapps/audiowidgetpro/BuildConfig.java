package com.smartandroidapps.audiowidgetpro;

public final class BuildConfig
{
  public static final boolean DEBUG;
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.smartandroidapps.audiowidgetpro.BuildConfig
 * JD-Core Version:    0.7.0.1
 */