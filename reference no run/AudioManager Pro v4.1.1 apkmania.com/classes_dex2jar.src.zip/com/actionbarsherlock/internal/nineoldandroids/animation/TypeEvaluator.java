package com.actionbarsherlock.internal.nineoldandroids.animation;

public abstract interface TypeEvaluator<T>
{
  public abstract T evaluate(float paramFloat, T paramT1, T paramT2);
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator
 * JD-Core Version:    0.7.0.1
 */