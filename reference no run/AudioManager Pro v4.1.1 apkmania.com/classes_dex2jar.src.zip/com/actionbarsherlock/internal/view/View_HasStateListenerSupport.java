package com.actionbarsherlock.internal.view;

public abstract interface View_HasStateListenerSupport
{
  public abstract void addOnAttachStateChangeListener(View_OnAttachStateChangeListener paramView_OnAttachStateChangeListener);
  
  public abstract void removeOnAttachStateChangeListener(View_OnAttachStateChangeListener paramView_OnAttachStateChangeListener);
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.internal.view.View_HasStateListenerSupport
 * JD-Core Version:    0.7.0.1
 */