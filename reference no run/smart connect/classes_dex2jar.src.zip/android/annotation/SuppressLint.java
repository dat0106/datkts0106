

java.lang.annotation.Annotation
java.lang.annotation.Retention
java.lang.annotation.RetentionPolicy
java.lang.annotation.Target

CLASS
TYPE, FIELD, METHOD, PARAMETER, CONSTRUCTOR, LOCAL_VARIABLE
SuppressLint

  []value



/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     android.annotation.SuppressLint
 * JD-Core Version:    0.7.0.1
 */