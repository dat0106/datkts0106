

java.lang.annotation.Annotation
java.lang.annotation.Retention
java.lang.annotation.RetentionPolicy
java.lang.annotation.Target

CLASS
TYPE, METHOD, CONSTRUCTOR
TargetApi

  value



/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     android.annotation.TargetApi
 * JD-Core Version:    0.7.0.1
 */