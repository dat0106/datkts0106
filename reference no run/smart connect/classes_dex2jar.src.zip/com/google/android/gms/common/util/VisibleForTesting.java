package com.google.android.gms.common.util;

import java.lang.annotation.Annotation;

public @interface VisibleForTesting {}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.util.VisibleForTesting
 * JD-Core Version:    0.7.0.1
 */