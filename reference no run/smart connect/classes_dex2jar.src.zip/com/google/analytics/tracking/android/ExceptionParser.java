package com.google.analytics.tracking.android;

public abstract interface ExceptionParser
{
  public abstract String getDescription(String paramString, Throwable paramThrowable);
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.ExceptionParser
 * JD-Core Version:    0.7.0.1
 */