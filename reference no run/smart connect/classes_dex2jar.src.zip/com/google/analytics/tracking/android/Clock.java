package com.google.analytics.tracking.android;

abstract interface Clock
{
  public abstract long currentTimeMillis();
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.Clock
 * JD-Core Version:    0.7.0.1
 */