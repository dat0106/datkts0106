package com.google.analytics.tracking.android;

abstract interface AnalyticsStoreStateListener
{
  public abstract void reportStoreIsEmpty(boolean paramBoolean);
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.AnalyticsStoreStateListener
 * JD-Core Version:    0.7.0.1
 */