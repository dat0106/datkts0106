package com.sonymobile.smartconnect.action;

public abstract interface InternalActionAPI
{
  public static final String CHECK_COMPABILITY_ACTION = "com.sonymobile.smartconnect.action.CHECK_COMPABILITY_ACTION";
  public static final String CHECK_COMPABILITY_ACTION_RESPONSE_ACTION = "com.sonymobile.smartconnect.action.CHECK_COMPABILITY_ACTION_RESPONSE_ACTION";
  public static final String EXTRA_IS_COMPATIBILE = "is_compatible";
  public static final String EXTRA_SETTINGS_INJECT_RESULT = "inject_result";
  public static final String EXTRA_SETTING_INJECT = "setting_inject";
  public static final String META_DATA_ASK_COMPABILITY = "ask_compability";
  public static final String SETTINGS_INJECT_ACTION = "com.sonymobile.smartconnect.action.SETTINGS_INJECT";
  public static final String SETTINGS_INJECT_RESPONSE_ACTION = "com.sonymobile.smartconnect.action.SETTINGS_INJECT_RESPONSE_ACTION";
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonymobile.smartconnect.action.InternalActionAPI
 * JD-Core Version:    0.7.0.1
 */