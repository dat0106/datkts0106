package com.sonymobile.smartconnect.action;

public final class R
{
  public static final class string
  {
    public static final int app_name = 2131099648;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonymobile.smartconnect.action.R
 * JD-Core Version:    0.7.0.1
 */