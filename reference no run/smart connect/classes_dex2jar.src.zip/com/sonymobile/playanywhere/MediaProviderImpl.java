package com.sonymobile.playanywhere;

public class MediaProviderImpl
  extends MediaProvider
{
  public MediaProviderImpl(IMediaProvider paramIMediaProvider) {}
  
  public boolean registerProvider(MediaProviderCallback paramMediaProviderCallback)
  {
    throw new RuntimeException("stub");
  }
  
  public int streamBegin(long paramLong)
  {
    throw new RuntimeException("stub");
  }
  
  public int streamEnd()
  {
    throw new RuntimeException("stub");
  }
  
  public void streamErrorHandler(boolean paramBoolean)
  {
    throw new RuntimeException("stub");
  }
  
  public int streamPause()
  {
    throw new RuntimeException("stub");
  }
  
  public long streamPosition()
  {
    throw new RuntimeException("stub");
  }
  
  public int streamPrepare(String paramString)
  {
    throw new RuntimeException("stub");
  }
  
  public int streamResume()
  {
    throw new RuntimeException("stub");
  }
  
  public long streamSeek(long paramLong)
  {
    throw new RuntimeException("stub");
  }
  
  public void unregisterProvider(MediaProviderCallback paramMediaProviderCallback)
  {
    throw new RuntimeException("stub");
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonymobile.playanywhere.MediaProviderImpl
 * JD-Core Version:    0.7.0.1
 */