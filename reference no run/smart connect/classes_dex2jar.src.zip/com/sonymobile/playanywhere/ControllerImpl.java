package com.sonymobile.playanywhere;

import android.graphics.Bitmap;

public class ControllerImpl
  extends Controller
{
  public ControllerImpl(IController paramIController) {}
  
  public boolean getMirrorMode()
  {
    throw new RuntimeException("stub");
  }
  
  public int getOutputSink()
  {
    throw new RuntimeException("stub");
  }
  
  public int getSinkCapabilities(int paramInt)
  {
    throw new RuntimeException("stub");
  }
  
  public int getSinkId(String paramString)
  {
    throw new RuntimeException("stub");
  }
  
  public String getSinkMake(int paramInt)
  {
    throw new RuntimeException("stub");
  }
  
  public String getSinkModel(int paramInt)
  {
    throw new RuntimeException("stub");
  }
  
  public String getSinkName(int paramInt)
  {
    throw new RuntimeException("stub");
  }
  
  public Bitmap getSinkThumbnail(int paramInt)
  {
    throw new RuntimeException("stub");
  }
  
  public String getSinkUUID(int paramInt)
  {
    throw new RuntimeException("stub");
  }
  
  public int[] getSinks()
  {
    throw new RuntimeException("stub");
  }
  
  public boolean hasMirrorMode()
  {
    throw new RuntimeException("stub");
  }
  
  public boolean isOutputSinkStreaming()
  {
    throw new RuntimeException("stub");
  }
  
  public boolean registerController(ControllerCallback paramControllerCallback)
  {
    throw new RuntimeException("stub");
  }
  
  public boolean setMirrorMode(boolean paramBoolean)
  {
    throw new RuntimeException("stub");
  }
  
  public boolean setOutputSink(int paramInt)
  {
    throw new RuntimeException("stub");
  }
  
  public void unregisterController(ControllerCallback paramControllerCallback)
  {
    throw new RuntimeException("stub");
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonymobile.playanywhere.ControllerImpl
 * JD-Core Version:    0.7.0.1
 */