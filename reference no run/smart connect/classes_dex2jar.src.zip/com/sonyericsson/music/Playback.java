package com.sonyericsson.music;

public abstract interface Playback
{
  public static final String PERMISSION = "com.sonyericsson.permission.MUSICSERVICE";
  public static final String SERVICE = "com.sonyericsson.music.SERVICE";
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.music.Playback
 * JD-Core Version:    0.7.0.1
 */