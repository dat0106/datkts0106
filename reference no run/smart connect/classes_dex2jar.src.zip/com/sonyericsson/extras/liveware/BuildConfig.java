package com.sonyericsson.extras.liveware;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.BuildConfig
 * JD-Core Version:    0.7.0.1
 */