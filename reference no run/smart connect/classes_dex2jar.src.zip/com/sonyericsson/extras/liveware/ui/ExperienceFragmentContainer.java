package com.sonyericsson.extras.liveware.ui;

public abstract interface ExperienceFragmentContainer
{
  public abstract void closeExperience();
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.ui.ExperienceFragmentContainer
 * JD-Core Version:    0.7.0.1
 */