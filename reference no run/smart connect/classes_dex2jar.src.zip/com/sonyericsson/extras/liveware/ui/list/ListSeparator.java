package com.sonyericsson.extras.liveware.ui.list;

public class ListSeparator
{
  private final String mName;
  
  public ListSeparator(String paramString)
  {
    this.mName = paramString;
  }
  
  public String getName()
  {
    return this.mName;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.ui.list.ListSeparator
 * JD-Core Version:    0.7.0.1
 */