package com.sonyericsson.extras.liveware.tts;

public abstract interface TtsManagerListener
{
  public abstract void onInitCompleted(boolean paramBoolean);
  
  public abstract void onSpeechCompleted();
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.tts.TtsManagerListener
 * JD-Core Version:    0.7.0.1
 */