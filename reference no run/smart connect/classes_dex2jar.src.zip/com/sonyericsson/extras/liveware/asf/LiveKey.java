package com.sonyericsson.extras.liveware.asf;

public class LiveKey
{
  public static final String EXTRA_ID = "com.sonyericsson.extras.livekey.id";
  public static final String EXTRA_STATE = "com.sonyericsson.extras.livekey.state";
  public static final String EXTRA_TIMESTAMP = "com.sonyericsson.extras.livekey.timestamp";
  public static final String LIVEKEY_INTENT = "com.sonyericsson.extras.livekey";
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.asf.LiveKey
 * JD-Core Version:    0.7.0.1
 */