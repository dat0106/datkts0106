package com.sonyericsson.extras.liveware.asf;

public abstract interface InstallCallback
{
  public abstract void run(boolean paramBoolean);
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.asf.InstallCallback
 * JD-Core Version:    0.7.0.1
 */