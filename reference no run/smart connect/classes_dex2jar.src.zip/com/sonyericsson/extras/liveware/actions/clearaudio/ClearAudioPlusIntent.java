package com.sonyericsson.extras.liveware.actions.clearaudio;

public class ClearAudioPlusIntent
{
  public static final String ACTION_CLEARAUDIO_PLUS_REQUEST = "com.sonymobile.audioeffect.intent.action.CLEARAUDIO_PLUS_REQUEST";
  public static final String ACTION_CLEARAUDIO_PLUS_STATUS = "com.sonymobile.audioeffect.intent.action.CLEARAUDIO_PLUS_STATUS";
  public static final String EXTRA_CLEARAUDIO_PLUS_PACKAGE_NAME = "com.sonymobile.audioeffect.intent.extra.CLEARAUDIO_PLUS_PACKAGE_NAME";
  public static final String EXTRA_CLEARAUDIO_PLUS_STATUS = "com.sonymobile.audioeffect.intent.extra.CLEARAUDIO_PLUS_STATUS";
  private static final String PREFIX_ACTION = "com.sonymobile.audioeffect.intent.action.";
  private static final String PREFIX_EXTRA = "com.sonymobile.audioeffect.intent.extra.";
  public static final int STATUS_OFF = 0;
  public static final int STATUS_ON = 1;
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.clearaudio.ClearAudioPlusIntent
 * JD-Core Version:    0.7.0.1
 */