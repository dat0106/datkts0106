package com.sonyericsson.extras.liveware.actions.ttssms;

import com.sonyericsson.extras.liveware.actions.OnOffToggleActivity;

public class TtsSmsActivity
  extends OnOffToggleActivity
{
  protected int getDialogTitleResId()
  {
    return 2131099867;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.ttssms.TtsSmsActivity
 * JD-Core Version:    0.7.0.1
 */