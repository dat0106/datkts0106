package com.sonyericsson.extras.liveware.actions.datatraffic;

import com.sonyericsson.extras.liveware.actions.OnOffToggleActivity;

public class DataTrafficActivity
  extends OnOffToggleActivity
{
  protected int getDialogTitleResId()
  {
    return 2131099880;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.datatraffic.DataTrafficActivity
 * JD-Core Version:    0.7.0.1
 */