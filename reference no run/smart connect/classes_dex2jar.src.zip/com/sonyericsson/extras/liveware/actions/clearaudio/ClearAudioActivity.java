package com.sonyericsson.extras.liveware.actions.clearaudio;

import com.sonyericsson.extras.liveware.actions.OnOffToggleActivity;

public class ClearAudioActivity
  extends OnOffToggleActivity
{
  protected int getDialogTitleResId()
  {
    return 2131099990;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.clearaudio.ClearAudioActivity
 * JD-Core Version:    0.7.0.1
 */