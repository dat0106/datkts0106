package com.sonyericsson.extras.liveware.actions.bluetooth;

import com.sonyericsson.extras.liveware.actions.OnOffToggleActivity;

public class BluetoothActivity
  extends OnOffToggleActivity
{
  protected int getDialogTitleResId()
  {
    return 2131099847;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.bluetooth.BluetoothActivity
 * JD-Core Version:    0.7.0.1
 */