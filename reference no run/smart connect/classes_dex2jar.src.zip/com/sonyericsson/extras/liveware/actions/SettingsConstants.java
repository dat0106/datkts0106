package com.sonyericsson.extras.liveware.actions;

public class SettingsConstants
{
  public static final String EXTRA_SETTINGS_DIALOG_TITLE = "com.sonyericsson.extra.liveware.settings_dialog_title";
  public static final String EXTRA_SETTINGS_KEY = "com.sonyericsson.extra.liveware.settings_key";
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.SettingsConstants
 * JD-Core Version:    0.7.0.1
 */