package com.sonyericsson.extras.liveware.actions.wifidisplay;

import com.sonyericsson.extras.liveware.actions.OnOffToggleActivity;

public class WifiDisplayActivity
  extends OnOffToggleActivity
{
  protected int getDialogTitleResId()
  {
    return 2131099900;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.wifidisplay.WifiDisplayActivity
 * JD-Core Version:    0.7.0.1
 */