package com.sonyericsson.extras.liveware.actions.wifi;

import com.sonyericsson.extras.liveware.actions.OnOffToggleActivity;

public class WifiHotspotActivity
  extends OnOffToggleActivity
{
  protected int getDialogTitleResId()
  {
    return 2131099854;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.wifi.WifiHotspotActivity
 * JD-Core Version:    0.7.0.1
 */