package com.sonyericsson.extras.liveware.actions.wifi;

import com.sonyericsson.extras.liveware.actions.OnOffToggleActivity;

public class WifiActivity
  extends OnOffToggleActivity
{
  protected int getDialogTitleResId()
  {
    return 2131099853;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.actions.wifi.WifiActivity
 * JD-Core Version:    0.7.0.1
 */