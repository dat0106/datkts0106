package com.sonyericsson.extras.liveware;

public class DynamicResources
{
  public static final int[] DYNAMIC_DRAWABLE_RES;
  public static final int[] DYNAMIC_STRING_RES;
  
  static
  {
    int[] arrayOfInt = new int[92];
    arrayOfInt[0] = 2131099859;
    arrayOfInt[1] = 2131099858;
    arrayOfInt[2] = 2131099865;
    arrayOfInt[3] = 2131099761;
    arrayOfInt[4] = 2131099758;
    arrayOfInt[5] = 2131099755;
    arrayOfInt[6] = 2131099894;
    arrayOfInt[7] = 2131099763;
    arrayOfInt[8] = 2131099760;
    arrayOfInt[9] = 2131099764;
    arrayOfInt[10] = 2131099754;
    arrayOfInt[11] = 2131099765;
    arrayOfInt[12] = 2131099759;
    arrayOfInt[13] = 2131099751;
    arrayOfInt[14] = 2131099890;
    arrayOfInt[15] = 2131099664;
    arrayOfInt[16] = 2131099752;
    arrayOfInt[17] = 2131099765;
    arrayOfInt[18] = 2131099895;
    arrayOfInt[19] = 2131099762;
    arrayOfInt[20] = 2131099892;
    arrayOfInt[21] = 2131099763;
    arrayOfInt[22] = 2131099753;
    arrayOfInt[23] = 2131099749;
    arrayOfInt[24] = 2131099781;
    arrayOfInt[25] = 2131099663;
    arrayOfInt[26] = 2131099896;
    arrayOfInt[27] = 2131099886;
    arrayOfInt[28] = 2131099756;
    arrayOfInt[29] = 2131099750;
    arrayOfInt[30] = 2131099757;
    arrayOfInt[31] = 2131099754;
    arrayOfInt[32] = 2131099761;
    arrayOfInt[33] = 2131099888;
    arrayOfInt[34] = 2131099684;
    arrayOfInt[35] = 2131099677;
    arrayOfInt[36] = 2131099674;
    arrayOfInt[37] = 2131099893;
    arrayOfInt[38] = 2131099680;
    arrayOfInt[39] = 2131099683;
    arrayOfInt[40] = 2131099678;
    arrayOfInt[41] = 2131099917;
    arrayOfInt[42] = 2131099676;
    arrayOfInt[43] = 2131099672;
    arrayOfInt[44] = 2131099897;
    arrayOfInt[45] = 2131099891;
    arrayOfInt[46] = 2131099884;
    arrayOfInt[47] = 2131099671;
    arrayOfInt[48] = 2131099918;
    arrayOfInt[49] = 2131099883;
    arrayOfInt[50] = 2131099673;
    arrayOfInt[51] = 2131099687;
    arrayOfInt[52] = 2131099682;
    arrayOfInt[53] = 2131099920;
    arrayOfInt[54] = 2131099685;
    arrayOfInt[55] = 2131099681;
    arrayOfInt[56] = 2131099675;
    arrayOfInt[57] = 2131099919;
    arrayOfInt[58] = 2131099882;
    arrayOfInt[59] = 2131099887;
    arrayOfInt[60] = 2131099889;
    arrayOfInt[61] = 2131099690;
    arrayOfInt[62] = 2131099885;
    arrayOfInt[63] = 2131099679;
    arrayOfInt[64] = 2131099931;
    arrayOfInt[65] = 2131099686;
    arrayOfInt[66] = 2131099914;
    arrayOfInt[67] = 2131099916;
    arrayOfInt[68] = 2131099913;
    arrayOfInt[69] = 2131099915;
    arrayOfInt[70] = 2131099801;
    arrayOfInt[71] = 2131099807;
    arrayOfInt[72] = 2131099808;
    arrayOfInt[73] = 2131099952;
    arrayOfInt[74] = 2131099951;
    arrayOfInt[75] = 2131099870;
    arrayOfInt[76] = 2131099930;
    arrayOfInt[77] = 2131099962;
    arrayOfInt[78] = 2131099972;
    arrayOfInt[79] = 2131099977;
    arrayOfInt[80] = 2131099978;
    arrayOfInt[81] = 2131099979;
    arrayOfInt[82] = 2131099980;
    arrayOfInt[83] = 2131099981;
    arrayOfInt[84] = 2131099982;
    arrayOfInt[85] = 2131099983;
    arrayOfInt[86] = 2131099984;
    arrayOfInt[87] = 2131099985;
    arrayOfInt[88] = 2131099986;
    arrayOfInt[89] = 2131099987;
    arrayOfInt[90] = 2131099988;
    arrayOfInt[91] = 2131099989;
    DYNAMIC_STRING_RES = arrayOfInt;
    arrayOfInt = new int[65];
    arrayOfInt[0] = 2130837522;
    arrayOfInt[1] = 2130837512;
    arrayOfInt[2] = 2130837510;
    arrayOfInt[3] = 2130837509;
    arrayOfInt[4] = 2130837504;
    arrayOfInt[5] = 2130837524;
    arrayOfInt[6] = 2130837506;
    arrayOfInt[7] = 2130837513;
    arrayOfInt[8] = 2130837514;
    arrayOfInt[9] = 2130837515;
    arrayOfInt[10] = 2130837525;
    arrayOfInt[11] = 2130837530;
    arrayOfInt[12] = 2130837527;
    arrayOfInt[13] = 2130837516;
    arrayOfInt[14] = 2130837517;
    arrayOfInt[15] = 2130837526;
    arrayOfInt[16] = 2130837505;
    arrayOfInt[17] = 2130837521;
    arrayOfInt[18] = 2130837518;
    arrayOfInt[19] = 2130837519;
    arrayOfInt[20] = 2130837523;
    arrayOfInt[21] = 2130837529;
    arrayOfInt[22] = 2130837520;
    arrayOfInt[23] = 2130837531;
    arrayOfInt[24] = 2130837532;
    arrayOfInt[25] = 2130837536;
    arrayOfInt[26] = 2130837535;
    arrayOfInt[27] = 2130837546;
    arrayOfInt[28] = 2130837548;
    arrayOfInt[29] = 2130837549;
    arrayOfInt[30] = 2130837544;
    arrayOfInt[31] = 2130837539;
    arrayOfInt[32] = 2130837541;
    arrayOfInt[33] = 2130837543;
    arrayOfInt[34] = 2130837538;
    arrayOfInt[35] = 2130837547;
    arrayOfInt[36] = 2130837545;
    arrayOfInt[37] = 2130837542;
    arrayOfInt[38] = 2130837583;
    arrayOfInt[39] = 2130837580;
    arrayOfInt[40] = 2130837585;
    arrayOfInt[41] = 2130837577;
    arrayOfInt[42] = 2130837572;
    arrayOfInt[43] = 2130837578;
    arrayOfInt[44] = 2130837586;
    arrayOfInt[45] = 2130837579;
    arrayOfInt[46] = 2130837588;
    arrayOfInt[47] = 2130837587;
    arrayOfInt[48] = 2130837574;
    arrayOfInt[49] = 2130837577;
    arrayOfInt[50] = 2130837582;
    arrayOfInt[51] = 2130837584;
    arrayOfInt[52] = 2130837581;
    arrayOfInt[53] = 2130837652;
    arrayOfInt[54] = 2130837653;
    arrayOfInt[55] = 2130837654;
    arrayOfInt[56] = 2130837656;
    arrayOfInt[57] = 2130837661;
    arrayOfInt[58] = 2130837647;
    arrayOfInt[59] = 2130837659;
    arrayOfInt[60] = 2130837645;
    arrayOfInt[61] = 2130837655;
    arrayOfInt[62] = 2130837662;
    arrayOfInt[63] = 2130837660;
    arrayOfInt[64] = 2130837657;
    DYNAMIC_DRAWABLE_RES = arrayOfInt;
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.DynamicResources
 * JD-Core Version:    0.7.0.1
 */