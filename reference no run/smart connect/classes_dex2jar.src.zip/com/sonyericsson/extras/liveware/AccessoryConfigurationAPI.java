package com.sonyericsson.extras.liveware;

public final class AccessoryConfigurationAPI
{
  public static final String ACCESSORY_CONFIGURATION_CHANGE = "com.sonyericsson.extras.liveware.ACCESSORY_CONFIGURATION_CHANGE";
  public static final int ACCESSORY_CONFIGURATION_TYPE_ORIENTATION = 1;
  public static final int ACCESSORY_CONNECTION_STATE_CONNECTED = 1;
  public static final int ACCESSORY_CONNECTION_STATE_DISCONNECTED = 0;
  public static final String EXTRA_ACCESSORY_CONFIGURATION_TYPES = "com.sonyericsson.extras.liveware.extra.EXTRA_ACCESSORY_CONFIGURATION_TYPES";
  public static final String EXTRA_ACCESSORY_CONNECTION_STATE = "com.sonyericsson.extras.liveware.extra.EXTRA_ACCESSORY_CONNECTION_STATE";
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.AccessoryConfigurationAPI
 * JD-Core Version:    0.7.0.1
 */