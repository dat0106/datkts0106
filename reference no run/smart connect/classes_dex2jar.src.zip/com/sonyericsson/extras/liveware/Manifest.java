package com.sonyericsson.extras.liveware;

public final class Manifest
{
  public static final class permission
  {
    public static final String DEVICE_CONFIGURED_PERMISSION = "com.sonyericsson.extras.liveware.DEVICE_CONFIGURED_PERMISSION";
    public static final String EXTENSION_PERMISSION = "com.sonyericsson.extras.liveware.aef.EXTENSION_PERMISSION";
    public static final String HOSTAPP_PERMISSION = "com.sonyericsson.extras.liveware.aef.HOSTAPP_PERMISSION";
  }
  
  public static final class permission_group
  {
    public static final String DISPLAY_YOUR_DATA = "com.sonyericsson.extras.liveware.aef.permission-group.DISPLAY_YOUR_DATA";
    public static final String STORE_YOUR_DATA = "com.sonyericsson.extras.liveware.aef.permission-group.STORE_YOUR_DATA";
  }
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.Manifest
 * JD-Core Version:    0.7.0.1
 */