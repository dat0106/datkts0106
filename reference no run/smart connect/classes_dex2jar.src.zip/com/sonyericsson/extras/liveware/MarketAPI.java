package com.sonyericsson.extras.liveware;

public class MarketAPI
{
  public static final String EXTRA_ACCESSORY_PRODUCT_NAME = "com.sonyericsson.extras.liveware.extra.ACCESSORY_PRODUCT_NAME";
  public static final String EXTRA_AEA_PACKAGE_NAME = "com.sonyericsson.extras.liveware.extra.AEA_PACKAGE_NAME";
  public static final String MARKET_EXTENSIONS_SEARCH_INTENT = "com.sonyericsson.extras.liveware.MARKET_EXTENSIONS_SEARCH";
  public static final String MARKET_EXTENSION_INFO_INTENT = "com.sonyericsson.extras.liveware.MARKET_EXTENSION_INFO";
}


/* Location:           D:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.sonyericsson.extras.liveware.MarketAPI
 * JD-Core Version:    0.7.0.1
 */