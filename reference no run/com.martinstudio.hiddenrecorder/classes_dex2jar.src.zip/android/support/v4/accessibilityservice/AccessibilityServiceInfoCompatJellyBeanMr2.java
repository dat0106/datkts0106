

android.accessibilityservice.AccessibilityServiceInfo

AccessibilityServiceInfoCompatJellyBeanMr2

  getCapabilities
  
    getCapabilities()
  



/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatJellyBeanMr2
 * JD-Core Version:    0.7.0.1
 */