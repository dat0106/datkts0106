package com.google.ads.mediation.customevent;

@Deprecated
public abstract interface CustomEvent
{
  public abstract void destroy();
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.ads.mediation.customevent.CustomEvent
 * JD-Core Version:    0.7.0.1
 */