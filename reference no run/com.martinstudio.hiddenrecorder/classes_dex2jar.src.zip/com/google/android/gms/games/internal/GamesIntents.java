package com.google.android.gms.games.internal;

public final class GamesIntents
{
  private GamesIntents()
  {
    throw new AssertionError("OneUpIntents should never be instantiated!");
  }
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.internal.GamesIntents
 * JD-Core Version:    0.7.0.1
 */