package com.google.android.gms.games.internal.constants;

public final class NotificationChannel {}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.internal.constants.NotificationChannel
 * JD-Core Version:    0.7.0.1
 */