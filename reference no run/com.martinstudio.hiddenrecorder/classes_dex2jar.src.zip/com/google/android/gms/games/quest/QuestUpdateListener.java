package com.google.android.gms.games.quest;

public abstract interface QuestUpdateListener
{
  public abstract void onQuestCompleted(Quest paramQuest);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.quest.QuestUpdateListener
 * JD-Core Version:    0.7.0.1
 */