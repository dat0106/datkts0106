package com.google.android.gms.games.internal;

import com.google.android.gms.internal.hg;

public final class JingleLog
{
  private static final hg OS = new hg("GamesJingle");
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.internal.JingleLog
 * JD-Core Version:    0.7.0.1
 */