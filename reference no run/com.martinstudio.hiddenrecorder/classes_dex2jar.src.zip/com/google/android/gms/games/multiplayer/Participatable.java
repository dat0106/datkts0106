package com.google.android.gms.games.multiplayer;

import java.util.ArrayList;

public abstract interface Participatable
{
  public abstract ArrayList<Participant> getParticipants();
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.Participatable
 * JD-Core Version:    0.7.0.1
 */