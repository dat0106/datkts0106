package com.google.android.gms.games.internal.experience;

public abstract interface ExperienceEvent
{
  @Deprecated
  public abstract String getIconImageUrl();
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.internal.experience.ExperienceEvent
 * JD-Core Version:    0.7.0.1
 */