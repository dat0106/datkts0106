package com.google.android.gms.games.multiplayer;

public abstract interface OnInvitationReceivedListener
{
  public abstract void onInvitationReceived(Invitation paramInvitation);
  
  public abstract void onInvitationRemoved(String paramString);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.OnInvitationReceivedListener
 * JD-Core Version:    0.7.0.1
 */