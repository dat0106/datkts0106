package com.google.android.gms.games.internal;

import com.google.android.gms.internal.hg;

public final class GamesLog
{
  private static final hg OS = new hg("Games");
  
  public static void a(String paramString1, String paramString2, Throwable paramThrowable)
  {
    OS.a(paramString1, paramString2, paramThrowable);
  }
  
  public static void b(String paramString1, String paramString2, Throwable paramThrowable)
  {
    OS.b(paramString1, paramString2, paramThrowable);
  }
  
  public static void i(String paramString1, String paramString2)
  {
    OS.i(paramString1, paramString2);
  }
  
  public static void j(String paramString1, String paramString2)
  {
    OS.j(paramString1, paramString2);
  }
  
  public static void k(String paramString1, String paramString2)
  {
    OS.k(paramString1, paramString2);
  }
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.internal.GamesLog
 * JD-Core Version:    0.7.0.1
 */