package com.google.android.gms.games.request;

public abstract interface OnRequestReceivedListener
{
  public abstract void onRequestReceived(GameRequest paramGameRequest);
  
  public abstract void onRequestRemoved(String paramString);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.request.OnRequestReceivedListener
 * JD-Core Version:    0.7.0.1
 */