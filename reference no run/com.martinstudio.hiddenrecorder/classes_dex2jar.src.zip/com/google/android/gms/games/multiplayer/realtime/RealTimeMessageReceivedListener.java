package com.google.android.gms.games.multiplayer.realtime;

public abstract interface RealTimeMessageReceivedListener
{
  public abstract void onRealTimeMessageReceived(RealTimeMessage paramRealTimeMessage);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.realtime.RealTimeMessageReceivedListener
 * JD-Core Version:    0.7.0.1
 */