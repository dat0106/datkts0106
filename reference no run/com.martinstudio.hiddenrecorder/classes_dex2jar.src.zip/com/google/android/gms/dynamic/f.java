package com.google.android.gms.dynamic;

public abstract interface f<T extends LifecycleDelegate>
{
  public abstract void a(T paramT);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.dynamic.f
 * JD-Core Version:    0.7.0.1
 */