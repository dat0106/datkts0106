package com.google.android.gms.analytics;

abstract interface ad
{
  public abstract boolean dj();
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.ad
 * JD-Core Version:    0.7.0.1
 */