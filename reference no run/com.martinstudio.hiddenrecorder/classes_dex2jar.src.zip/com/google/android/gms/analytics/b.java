package com.google.android.gms.analytics;

import com.google.android.gms.internal.fe;
import java.util.List;
import java.util.Map;

abstract interface b
{
  public abstract void a(Map<String, String> paramMap, long paramLong, String paramString, List<fe> paramList);
  
  public abstract void cg();
  
  public abstract void connect();
  
  public abstract void disconnect();
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.b
 * JD-Core Version:    0.7.0.1
 */