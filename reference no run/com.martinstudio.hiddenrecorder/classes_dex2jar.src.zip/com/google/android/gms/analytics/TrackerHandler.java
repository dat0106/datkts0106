package com.google.android.gms.analytics;

import java.util.Map;

abstract class TrackerHandler
{
  abstract void p(Map<String, String> paramMap);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.TrackerHandler
 * JD-Core Version:    0.7.0.1
 */