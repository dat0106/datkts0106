package com.google.android.gms.analytics;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

abstract interface f
{
  public abstract void cg();
  
  public abstract void cl();
  
  public abstract void cn();
  
  public abstract LinkedBlockingQueue<Runnable> co();
  
  public abstract Thread getThread();
  
  public abstract void p(Map<String, String> paramMap);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.f
 * JD-Core Version:    0.7.0.1
 */