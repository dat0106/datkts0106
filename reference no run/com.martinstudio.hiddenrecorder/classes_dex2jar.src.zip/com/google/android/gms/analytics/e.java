package com.google.android.gms.analytics;

abstract interface e
{
  public abstract void s(boolean paramBoolean);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.e
 * JD-Core Version:    0.7.0.1
 */