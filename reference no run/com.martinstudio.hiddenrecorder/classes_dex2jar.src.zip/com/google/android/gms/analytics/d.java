package com.google.android.gms.analytics;

import com.google.android.gms.internal.fe;
import java.util.Collection;
import java.util.Map;

abstract interface d
{
  public abstract void a(Map<String, String> paramMap, long paramLong, String paramString, Collection<fe> paramCollection);
  
  public abstract void cl();
  
  public abstract n cm();
  
  public abstract void l(long paramLong);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.d
 * JD-Core Version:    0.7.0.1
 */