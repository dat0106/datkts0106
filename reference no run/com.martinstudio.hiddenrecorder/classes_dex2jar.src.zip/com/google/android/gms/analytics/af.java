package com.google.android.gms.analytics;

abstract class af
{
  abstract void cD();
  
  abstract void dispatchLocalHits();
  
  abstract void setLocalDispatchPeriod(int paramInt);
  
  abstract void t(boolean paramBoolean);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.af
 * JD-Core Version:    0.7.0.1
 */