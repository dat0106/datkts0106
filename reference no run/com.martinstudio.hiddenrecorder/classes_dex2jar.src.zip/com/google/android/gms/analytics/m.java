package com.google.android.gms.analytics;

abstract interface m
{
  public abstract String getValue(String paramString);
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.analytics.m
 * JD-Core Version:    0.7.0.1
 */