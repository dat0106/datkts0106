package com.google.android.gms.drive.query;

public abstract interface Filter {}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.drive.query.Filter
 * JD-Core Version:    0.7.0.1
 */