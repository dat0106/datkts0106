package com.google.android.gms.common.api;

public final class BatchResultToken<R extends Result>
{
  protected final int mId;
  
  BatchResultToken(int paramInt)
  {
    this.mId = paramInt;
  }
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.BatchResultToken
 * JD-Core Version:    0.7.0.1
 */