package com.google.android.gms.common.api;

public final class Scope
{
  private final String Ej;
  
  public Scope(String paramString)
  {
    this.Ej = paramString;
  }
  
  public String eK()
  {
    return this.Ej;
  }
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Scope
 * JD-Core Version:    0.7.0.1
 */