package com.google.android.gms.common.api;

public abstract interface Result
{
  public abstract Status getStatus();
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Result
 * JD-Core Version:    0.7.0.1
 */