package com.google.android.gms.ads.mediation.customevent;

public abstract interface CustomEvent
{
  public abstract void onDestroy();
  
  public abstract void onPause();
  
  public abstract void onResume();
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.mediation.customevent.CustomEvent
 * JD-Core Version:    0.7.0.1
 */