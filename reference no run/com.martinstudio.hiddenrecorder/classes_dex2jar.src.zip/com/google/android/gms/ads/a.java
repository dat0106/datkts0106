package com.google.android.gms.ads;

public final class a
{
  public static AdSize a(int paramInt1, int paramInt2, String paramString)
  {
    return new AdSize(paramInt1, paramInt2, paramString);
  }
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.a
 * JD-Core Version:    0.7.0.1
 */