package com.google.android.gms.ads.mediation;

public abstract interface NetworkExtras {}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.mediation.NetworkExtras
 * JD-Core Version:    0.7.0.1
 */