package com.google.android.gms;

public final class R
{
  public static final class attr
  {
    public static final int adSize = 2130771968;
    public static final int adSizes = 2130771969;
    public static final int adUnitId = 2130771970;
    public static final int buyButtonAppearance = 2130771992;
    public static final int buyButtonHeight = 2130771989;
    public static final int buyButtonText = 2130771991;
    public static final int buyButtonWidth = 2130771990;
    public static final int cameraBearing = 2130771972;
    public static final int cameraTargetLat = 2130771973;
    public static final int cameraTargetLng = 2130771974;
    public static final int cameraTilt = 2130771975;
    public static final int cameraZoom = 2130771976;
    public static final int environment = 2130771986;
    public static final int fragmentMode = 2130771988;
    public static final int fragmentStyle = 2130771987;
    public static final int mapType = 2130771971;
    public static final int maskedWalletDetailsBackground = 2130771995;
    public static final int maskedWalletDetailsButtonBackground = 2130771997;
    public static final int maskedWalletDetailsButtonTextAppearance = 2130771996;
    public static final int maskedWalletDetailsHeaderTextAppearance = 2130771994;
    public static final int maskedWalletDetailsLogoImageType = 2130771999;
    public static final int maskedWalletDetailsLogoTextColor = 2130771998;
    public static final int maskedWalletDetailsTextAppearance = 2130771993;
    public static final int theme = 2130771985;
    public static final int uiCompass = 2130771977;
    public static final int uiRotateGestures = 2130771978;
    public static final int uiScrollGestures = 2130771979;
    public static final int uiTiltGestures = 2130771980;
    public static final int uiZoomControls = 2130771981;
    public static final int uiZoomGestures = 2130771982;
    public static final int useViewLifecycle = 2130771983;
    public static final int zOrderOnTop = 2130771984;
  }
  
  public static final class color
  {
    public static final int common_action_bar_splitter = 2131230729;
    public static final int common_signin_btn_dark_text_default = 2131230720;
    public static final int common_signin_btn_dark_text_disabled = 2131230722;
    public static final int common_signin_btn_dark_text_focused = 2131230723;
    public static final int common_signin_btn_dark_text_pressed = 2131230721;
    public static final int common_signin_btn_default_background = 2131230728;
    public static final int common_signin_btn_light_text_default = 2131230724;
    public static final int common_signin_btn_light_text_disabled = 2131230726;
    public static final int common_signin_btn_light_text_focused = 2131230727;
    public static final int common_signin_btn_light_text_pressed = 2131230725;
    public static final int common_signin_btn_text_dark = 2131230743;
    public static final int common_signin_btn_text_light = 2131230744;
    public static final int wallet_bright_foreground_disabled_holo_light = 2131230735;
    public static final int wallet_bright_foreground_holo_dark = 2131230730;
    public static final int wallet_bright_foreground_holo_light = 2131230736;
    public static final int wallet_dim_foreground_disabled_holo_dark = 2131230732;
    public static final int wallet_dim_foreground_holo_dark = 2131230731;
    public static final int wallet_dim_foreground_inverse_disabled_holo_dark = 2131230734;
    public static final int wallet_dim_foreground_inverse_holo_dark = 2131230733;
    public static final int wallet_highlighted_text_holo_dark = 2131230740;
    public static final int wallet_highlighted_text_holo_light = 2131230739;
    public static final int wallet_hint_foreground_holo_dark = 2131230738;
    public static final int wallet_hint_foreground_holo_light = 2131230737;
    public static final int wallet_holo_blue_light = 2131230741;
    public static final int wallet_link_text_light = 2131230742;
    public static final int wallet_primary_text_holo_light = 2131230745;
    public static final int wallet_secondary_text_holo_dark = 2131230746;
  }
  
  public static final class drawable
  {
    public static final int common_signin_btn_icon_dark = 2130837506;
    public static final int common_signin_btn_icon_disabled_dark = 2130837507;
    public static final int common_signin_btn_icon_disabled_focus_dark = 2130837508;
    public static final int common_signin_btn_icon_disabled_focus_light = 2130837509;
    public static final int common_signin_btn_icon_disabled_light = 2130837510;
    public static final int common_signin_btn_icon_focus_dark = 2130837511;
    public static final int common_signin_btn_icon_focus_light = 2130837512;
    public static final int common_signin_btn_icon_light = 2130837513;
    public static final int common_signin_btn_icon_normal_dark = 2130837514;
    public static final int common_signin_btn_icon_normal_light = 2130837515;
    public static final int common_signin_btn_icon_pressed_dark = 2130837516;
    public static final int common_signin_btn_icon_pressed_light = 2130837517;
    public static final int common_signin_btn_text_dark = 2130837518;
    public static final int common_signin_btn_text_disabled_dark = 2130837519;
    public static final int common_signin_btn_text_disabled_focus_dark = 2130837520;
    public static final int common_signin_btn_text_disabled_focus_light = 2130837521;
    public static final int common_signin_btn_text_disabled_light = 2130837522;
    public static final int common_signin_btn_text_focus_dark = 2130837523;
    public static final int common_signin_btn_text_focus_light = 2130837524;
    public static final int common_signin_btn_text_light = 2130837525;
    public static final int common_signin_btn_text_normal_dark = 2130837526;
    public static final int common_signin_btn_text_normal_light = 2130837527;
    public static final int common_signin_btn_text_pressed_dark = 2130837528;
    public static final int common_signin_btn_text_pressed_light = 2130837529;
    public static final int ic_plusone_medium_off_client = 2130837534;
    public static final int ic_plusone_small_off_client = 2130837535;
    public static final int ic_plusone_standard_off_client = 2130837536;
    public static final int ic_plusone_tall_off_client = 2130837537;
    public static final int powered_by_google_dark = 2130837543;
    public static final int powered_by_google_light = 2130837544;
  }
  
  public static final class id
  {
    public static final int book_now = 2131296272;
    public static final int buyButton = 2131296266;
    public static final int buy_now = 2131296271;
    public static final int buy_with_google = 2131296270;
    public static final int classic = 2131296273;
    public static final int grayscale = 2131296274;
    public static final int holo_dark = 2131296261;
    public static final int holo_light = 2131296262;
    public static final int hybrid = 2131296260;
    public static final int match_parent = 2131296268;
    public static final int monochrome = 2131296275;
    public static final int none = 2131296256;
    public static final int normal = 2131296257;
    public static final int production = 2131296263;
    public static final int sandbox = 2131296264;
    public static final int satellite = 2131296258;
    public static final int selectionDetails = 2131296267;
    public static final int strict_sandbox = 2131296265;
    public static final int terrain = 2131296259;
    public static final int wrap_content = 2131296269;
  }
  
  public static final class integer
  {
    public static final int google_play_services_version = 2131361792;
  }
  
  public static final class string
  {
    public static final int auth_client_needs_enabling_title = 2131165185;
    public static final int auth_client_needs_installation_title = 2131165186;
    public static final int auth_client_needs_update_title = 2131165187;
    public static final int auth_client_play_services_err_notification_msg = 2131165188;
    public static final int auth_client_requested_by_msg = 2131165189;
    public static final int auth_client_using_bad_version_title = 2131165184;
    public static final int common_google_play_services_enable_button = 2131165201;
    public static final int common_google_play_services_enable_text = 2131165200;
    public static final int common_google_play_services_enable_title = 2131165199;
    public static final int common_google_play_services_error_notification_requested_by_msg = 2131165194;
    public static final int common_google_play_services_install_button = 2131165198;
    public static final int common_google_play_services_install_text_phone = 2131165196;
    public static final int common_google_play_services_install_text_tablet = 2131165197;
    public static final int common_google_play_services_install_title = 2131165195;
    public static final int common_google_play_services_invalid_account_text = 2131165207;
    public static final int common_google_play_services_invalid_account_title = 2131165206;
    public static final int common_google_play_services_needs_enabling_title = 2131165193;
    public static final int common_google_play_services_network_error_text = 2131165205;
    public static final int common_google_play_services_network_error_title = 2131165204;
    public static final int common_google_play_services_notification_needs_installation_title = 2131165191;
    public static final int common_google_play_services_notification_needs_update_title = 2131165192;
    public static final int common_google_play_services_notification_ticker = 2131165190;
    public static final int common_google_play_services_unknown_issue = 2131165208;
    public static final int common_google_play_services_unsupported_date_text = 2131165211;
    public static final int common_google_play_services_unsupported_text = 2131165210;
    public static final int common_google_play_services_unsupported_title = 2131165209;
    public static final int common_google_play_services_update_button = 2131165212;
    public static final int common_google_play_services_update_text = 2131165203;
    public static final int common_google_play_services_update_title = 2131165202;
    public static final int common_signin_button_text = 2131165213;
    public static final int common_signin_button_text_long = 2131165214;
    public static final int wallet_buy_button_place_holder = 2131165215;
  }
  
  public static final class style
  {
    public static final int Theme_IAPTheme = 2131099648;
    public static final int WalletFragmentDefaultButtonTextAppearance = 2131099651;
    public static final int WalletFragmentDefaultDetailsHeaderTextAppearance = 2131099650;
    public static final int WalletFragmentDefaultDetailsTextAppearance = 2131099649;
    public static final int WalletFragmentDefaultStyle = 2131099652;
  }
  
  public static final class styleable
  {
    public static final int[] AdsAttrs;
    public static final int AdsAttrs_adSize = 0;
    public static final int AdsAttrs_adSizes = 1;
    public static final int AdsAttrs_adUnitId = 2;
    public static final int[] MapAttrs;
    public static final int MapAttrs_cameraBearing = 1;
    public static final int MapAttrs_cameraTargetLat = 2;
    public static final int MapAttrs_cameraTargetLng = 3;
    public static final int MapAttrs_cameraTilt = 4;
    public static final int MapAttrs_cameraZoom = 5;
    public static final int MapAttrs_mapType = 0;
    public static final int MapAttrs_uiCompass = 6;
    public static final int MapAttrs_uiRotateGestures = 7;
    public static final int MapAttrs_uiScrollGestures = 8;
    public static final int MapAttrs_uiTiltGestures = 9;
    public static final int MapAttrs_uiZoomControls = 10;
    public static final int MapAttrs_uiZoomGestures = 11;
    public static final int MapAttrs_useViewLifecycle = 12;
    public static final int MapAttrs_zOrderOnTop = 13;
    public static final int[] WalletFragmentOptions;
    public static final int WalletFragmentOptions_environment = 1;
    public static final int WalletFragmentOptions_fragmentMode = 3;
    public static final int WalletFragmentOptions_fragmentStyle = 2;
    public static final int WalletFragmentOptions_theme = 0;
    public static final int[] WalletFragmentStyle;
    public static final int WalletFragmentStyle_buyButtonAppearance = 3;
    public static final int WalletFragmentStyle_buyButtonHeight = 0;
    public static final int WalletFragmentStyle_buyButtonText = 2;
    public static final int WalletFragmentStyle_buyButtonWidth = 1;
    public static final int WalletFragmentStyle_maskedWalletDetailsBackground = 6;
    public static final int WalletFragmentStyle_maskedWalletDetailsButtonBackground = 8;
    public static final int WalletFragmentStyle_maskedWalletDetailsButtonTextAppearance = 7;
    public static final int WalletFragmentStyle_maskedWalletDetailsHeaderTextAppearance = 5;
    public static final int WalletFragmentStyle_maskedWalletDetailsLogoImageType = 10;
    public static final int WalletFragmentStyle_maskedWalletDetailsLogoTextColor = 9;
    public static final int WalletFragmentStyle_maskedWalletDetailsTextAppearance = 4;
    
    static
    {
      int[] arrayOfInt = new int[3];
      arrayOfInt[0] = 2130771968;
      arrayOfInt[1] = 2130771969;
      arrayOfInt[2] = 2130771970;
      AdsAttrs = arrayOfInt;
      arrayOfInt = new int[14];
      arrayOfInt[0] = 2130771971;
      arrayOfInt[1] = 2130771972;
      arrayOfInt[2] = 2130771973;
      arrayOfInt[3] = 2130771974;
      arrayOfInt[4] = 2130771975;
      arrayOfInt[5] = 2130771976;
      arrayOfInt[6] = 2130771977;
      arrayOfInt[7] = 2130771978;
      arrayOfInt[8] = 2130771979;
      arrayOfInt[9] = 2130771980;
      arrayOfInt[10] = 2130771981;
      arrayOfInt[11] = 2130771982;
      arrayOfInt[12] = 2130771983;
      arrayOfInt[13] = 2130771984;
      MapAttrs = arrayOfInt;
      arrayOfInt = new int[4];
      arrayOfInt[0] = 2130771985;
      arrayOfInt[1] = 2130771986;
      arrayOfInt[2] = 2130771987;
      arrayOfInt[3] = 2130771988;
      WalletFragmentOptions = arrayOfInt;
      arrayOfInt = new int[11];
      arrayOfInt[0] = 2130771989;
      arrayOfInt[1] = 2130771990;
      arrayOfInt[2] = 2130771991;
      arrayOfInt[3] = 2130771992;
      arrayOfInt[4] = 2130771993;
      arrayOfInt[5] = 2130771994;
      arrayOfInt[6] = 2130771995;
      arrayOfInt[7] = 2130771996;
      arrayOfInt[8] = 2130771997;
      arrayOfInt[9] = 2130771998;
      arrayOfInt[10] = 2130771999;
      WalletFragmentStyle = arrayOfInt;
    }
  }
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.R
 * JD-Core Version:    0.7.0.1
 */