package com.google.android.gms.actions;

public class ReserveIntents
{
  public static final String ACTION_RESERVE_TAXI_RESERVATION = "com.google.android.gms.actions.RESERVE_TAXI_RESERVATION";
}


/* Location:           E:\android\Androidvn\dex2jar\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.actions.ReserveIntents
 * JD-Core Version:    0.7.0.1
 */