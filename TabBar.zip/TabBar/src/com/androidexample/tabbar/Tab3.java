package com.androidexample.tabbar;

import android.os.Bundle;
import android.app.Activity;


public class Tab3 extends Activity {

	/** Called when the activity is first created. */
	  
	  @Override
	  public void onCreate(Bundle savedInstanceState) {
	      super.onCreate(savedInstanceState);
	      setContentView(R.layout.tab3);
	    }
}
